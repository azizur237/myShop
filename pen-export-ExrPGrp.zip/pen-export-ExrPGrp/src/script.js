document.addEventListener("DOMContentLoaded", function () {
    const productForm = document.getElementById("product-form");
    const productList = document.getElementById("product-list");

    productForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const productName = document.getElementById("product-name").value;
        const productPrice = document.getElementById("product-price").value;
        const productDescription = document.getElementById("product-description").value;
        const productImages = document.getElementById("product-images").files;

        const productItem = document.createElement("li");
        productItem.className = "product-list-item";
        
        // Display product details
        productItem.innerHTML = `<h3>${productName}</h3>
                                 <p>Price: INR ${productPrice}</p>
                                 <p>${productDescription}</p>`;

        // Display product images
        for (let i = 0; i < productImages.length; i++) {
            const image = document.createElement("img");
            image.src = URL.createObjectURL(productImages[i]);
            productItem.appendChild(image);
        }

        productList.appendChild(productItem);

        // Clear the form
        productForm.reset();
    });
});
